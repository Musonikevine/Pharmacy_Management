# Pharmacy-management
This system serves as a centralized platform for managing inventory, sales, and other administrative tasks, facilitating less communication between the head of the pharmacy and the sellers. 
